import Header from "../components/Header"
import Sidebar from "../components/Sidebar"
import DashboardMainContent from "../components/DashboardMainContent"
import "../styles/globals.css"

export default function HomePage() {
  return (
    <div className="app">
      <Header />
      <div className="app-body">
        <Sidebar />
        <DashboardMainContent />
      </div>
    </div>
  )
}
