const navigationItems = [
  { id: 1, name: "Dashboard", icon: "📊", active: true },
  { id: 2, name: "History", icon: "📋", active: false },
  { id: 3, name: "Calendar", icon: "📅", active: false },
  { id: 4, name: "Appointments", icon: "🏥", active: false },
  { id: 5, name: "Statistics", icon: "📈", active: false },
  { id: 6, name: "Tests", icon: "🧪", active: false },
  { id: 7, name: "Chat", icon: "💬", active: false },
  { id: 8, name: "Support", icon: "📞", active: false },
  { id: 9, name: "Setting", icon: "⚙️", active: false },
]

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="sidebar-content">
        <div className="sidebar-section">
          <h3 className="sidebar-title">General</h3>
          <nav className="sidebar-nav">
            {navigationItems.map((item) => (
              <a key={item.id} href="#" className={`nav-item ${item.active ? "active" : ""}`}>
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-text">{item.name}</span>
              </a>
            ))}
          </nav>
        </div>
      </div>
    </aside>
  )
}
