import SimpleAppointmentCard from "./SimpleAppointmentCard"

const upcomingSchedule = [
  {
    day: "On Thursday",
    appointments: [
      { id: 1, title: "Health checkup complete", time: "11:00 AM", icon: "✅" },
      { id: 2, title: "Ophthalmologist", time: "14:00 PM", icon: "👁️" },
    ],
  },
  {
    day: "On Saturday",
    appointments: [
      { id: 3, title: "Cardiologist", time: "12:00 AM", icon: "❤️" },
      { id: 4, title: "Neurologist", time: "16:00 PM", icon: "🧠" },
    ],
  },
]

export default function UpcomingSchedule() {
  return (
    <div className="upcoming-schedule">
      <h2 className="schedule-title">The Upcoming Schedule</h2>

      {upcomingSchedule.map((daySchedule, index) => (
        <div key={index} className="day-schedule">
          <h3 className="day-title">{daySchedule.day}</h3>
          <div className="appointments-list">
            {daySchedule.appointments.map((appointment) => (
              <SimpleAppointmentCard key={appointment.id} appointment={appointment} />
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
