const calendarData = {
  month: "October 2021",
  days: [
    { date: 25, day: "Mon", appointments: ["10:00", "11:00", "12:00"] },
    { date: 26, day: "Tues", appointments: ["08:00", "09:00", "10:00"] },
    { date: 27, day: "Wed", appointments: ["12:00", "13:00"] },
    { date: 28, day: "Thurs", appointments: ["10:00"] },
    { date: 29, day: "Fri", appointments: ["11:00", "14:00", "16:00"] },
    { date: 30, day: "Sat", appointments: ["09:00", "14:00", "15:00"] },
    { date: 31, day: "Sun", appointments: ["09:00"] },
  ],
}

const appointmentCards = [
  {
    id: 1,
    type: "Dentist",
    time: "09:00-11:00",
    doctor: "Dr. Cameron Williamson",
    color: "#3b82f6",
  },
  {
    id: 2,
    type: "Physiotherapy Appointment",
    time: "11:00-12:00",
    doctor: "Dr. Kevin Djones",
    color: "#e5e7eb",
  },
]

export default function CalendarView() {
  return (
    <div className="calendar-section">
      <div className="calendar-header">
        <h2 className="calendar-title">{calendarData.month}</h2>
        <div className="calendar-nav">
          <button className="nav-btn">◀</button>
          <button className="nav-btn">▶</button>
        </div>
      </div>

      <div className="calendar-grid">
        {calendarData.days.map((day) => (
          <div key={day.date} className="calendar-day">
            <div className="day-header">
              <span className="day-name">{day.day}</span>
              <span className="day-number">{day.date}</span>
            </div>
            <div className="appointments">
              {day.appointments.map((time, index) => (
                <div key={index} className="appointment-time">
                  {time}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="appointment-cards">
        {appointmentCards.map((card) => (
          <div key={card.id} className="appointment-card" style={{ borderLeftColor: card.color }}>
            <h4 className="appointment-type">{card.type}</h4>
            <p className="appointment-time-range">{card.time}</p>
            <p className="appointment-doctor">{card.doctor}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
