const activityData = {
  weeklyAppointments: 3,
  chartData: [
    { day: "Mon", value: 20 },
    { day: "Tues", value: 45 },
    { day: "Wed", value: 30 },
    { day: "Thurs", value: 60 },
    { day: "Fri", value: 35 },
    { day: "Sat", value: 80 },
    { day: "Sun", value: 25 },
  ],
}

export default function ActivityFeed() {
  const maxValue = Math.max(...activityData.chartData.map((d) => d.value))

  return (
    <div className="activity-feed">
      <h2 className="activity-title">Activity</h2>
      <p className="activity-subtitle">{activityData.weeklyAppointments} appointments on this week</p>

      <div className="activity-chart">
        {activityData.chartData.map((data, index) => (
          <div key={index} className="chart-bar-container">
            <div
              className="chart-bar"
              style={{
                height: `${(data.value / maxValue) * 100}%`,
                backgroundColor: index % 2 === 0 ? "#06b6d4" : "#3b82f6",
              }}
            ></div>
            <span className="chart-label">{data.day}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
