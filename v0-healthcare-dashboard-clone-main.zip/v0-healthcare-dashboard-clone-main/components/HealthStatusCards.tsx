const healthStatusData = [
  {
    id: 1,
    name: "Lungs",
    icon: "🫁",
    date: "Born: 26 Oct, 2021",
    progress: 85,
    color: "#ef4444",
  },
  {
    id: 2,
    name: "Teeth",
    icon: "🦷",
    date: "Born: 26 Oct, 2021",
    progress: 70,
    color: "#10b981",
  },
  {
    id: 3,
    name: "Bone",
    icon: "🦴",
    date: "Born: 26 Oct, 2021",
    progress: 60,
    color: "#ef4444",
  },
]

export default function HealthStatusCards() {
  return (
    <div className="health-status-cards">
      {healthStatusData.map((item) => (
        <div key={item.id} className="health-card">
          <div className="health-card-header">
            <div className="health-icon">{item.icon}</div>
            <h3 className="health-title">{item.name}</h3>
          </div>
          <p className="health-date">{item.date}</p>
          <div className="progress-container">
            <div
              className="progress-bar"
              style={{
                width: `${item.progress}%`,
                backgroundColor: item.color,
              }}
            ></div>
          </div>
        </div>
      ))}
    </div>
  )
}
