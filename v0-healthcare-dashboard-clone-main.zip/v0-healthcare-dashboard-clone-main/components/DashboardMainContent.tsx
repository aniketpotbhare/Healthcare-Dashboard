import AnatomySection from "./AnatomySection"
import HealthStatusCards from "./HealthStatusCards"
import CalendarView from "./CalendarView"
import UpcomingSchedule from "./UpcomingSchedule"
import ActivityFeed from "./ActivityFeed"

export default function DashboardMainContent() {
  return (
    <main className="dashboard-main">
      <div className="dashboard-header">
        <h1 className="dashboard-title">Dashboard</h1>
        <div className="dashboard-controls">
          <select className="time-filter">
            <option>This Week</option>
            <option>This Month</option>
            <option>This Year</option>
          </select>
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="anatomy-column">
          <AnatomySection />
        </div>

        <div className="health-status-column">
          <HealthStatusCards />
        </div>

        <div className="calendar-column">
          <CalendarView />
        </div>

        <div className="schedule-column">
          <UpcomingSchedule />
        </div>

        <div className="activity-column">
          <ActivityFeed />
        </div>
      </div>
    </main>
  )
}
