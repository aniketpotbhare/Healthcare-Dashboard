const anatomyIndicators = [
  { id: 1, name: "Healthy Heart", position: { top: "35%", left: "45%" }, color: "#3b82f6" },
  { id: 2, name: "Healthy Leg", position: { top: "85%", left: "50%" }, color: "#06b6d4" },
]

export default function AnatomySection() {
  return (
    <div className="anatomy-section">
      <div className="anatomy-container">
        <div className="anatomy-figure">
          <img src="/placeholder.svg?height=400&width=200" alt="Human Anatomy" className="anatomy-image" />
          {anatomyIndicators.map((indicator) => (
            <div
              key={indicator.id}
              className="anatomy-indicator"
              style={{
                top: indicator.position.top,
                left: indicator.position.left,
                backgroundColor: indicator.color,
              }}
            >
              {indicator.name}
            </div>
          ))}
        </div>
        <div className="anatomy-controls">
          <button className="zoom-control">🔍</button>
          <div className="slider-container">
            <input type="range" className="zoom-slider" />
          </div>
        </div>
      </div>
    </div>
  )
}
