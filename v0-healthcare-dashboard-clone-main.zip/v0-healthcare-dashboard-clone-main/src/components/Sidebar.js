import { navigationItems } from "../data/navigationData.js"
import "./Sidebar.css"

const Sidebar = () => {
  return (
    <aside className="sidebar">
      <div className="sidebar-content">
        <div className="sidebar-section">
          <h3 className="sidebar-title">General</h3>
          <nav className="sidebar-nav">
            {navigationItems.map((item) => (
              <a key={item.id} href="#" className={`nav-item ${item.active ? "active" : ""}`}>
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-text">{item.name}</span>
              </a>
            ))}
          </nav>
        </div>
      </div>
    </aside>
  )
}

export default Sidebar
