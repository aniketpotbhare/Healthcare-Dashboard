import { calendarData, appointmentCards } from "../data/appointmentData.js"
import "./CalendarView.css"

const CalendarView = () => {
  return (
    <div className="calendar-section">
      <div className="calendar-header">
        <h2 className="calendar-title">{calendarData.month}</h2>
        <div className="calendar-nav">
          <button className="nav-btn">◀</button>
          <button className="nav-btn">▶</button>
        </div>
      </div>

      <div className="calendar-grid">
        {calendarData.days.map((day) => (
          <div key={day.date} className="calendar-day">
            <div className="day-header">
              <span className="day-name">{day.day}</span>
              <span className="day-number">{day.date}</span>
            </div>
            <div className="appointments">
              {day.appointments.map((time, index) => (
                <div key={index} className="appointment-time">
                  {time}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="appointment-cards">
        {appointmentCards.map((card) => (
          <div key={card.id} className="appointment-card" style={{ borderLeftColor: card.color }}>
            <h4 className="appointment-type">{card.type}</h4>
            <p className="appointment-time-range">{card.time}</p>
            <p className="appointment-doctor">{card.doctor}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default CalendarView
