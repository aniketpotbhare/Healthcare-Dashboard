import "./Header.css"

const Header = () => {
  return (
    <header className="header">
      <div className="header-left">
        <h1 className="logo">Healthcare.</h1>
      </div>

      <div className="header-center">
        <div className="search-container">
          <input type="text" placeholder="Search" className="search-input" />
          <span className="search-icon">🔍</span>
        </div>
      </div>

      <div className="header-right">
        <div className="notification-icon">🔔</div>
        <div className="user-profile">
          <img src="/placeholder.svg?height=40&width=40" alt="User Avatar" className="user-avatar" />
        </div>
        <button className="add-button">+</button>
      </div>
    </header>
  )
}

export default Header
