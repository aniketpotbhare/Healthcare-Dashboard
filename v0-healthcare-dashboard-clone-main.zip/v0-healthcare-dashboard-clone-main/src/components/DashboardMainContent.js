import AnatomySection from "./AnatomySection.js"
import HealthStatusCards from "./HealthStatusCards.js"
import CalendarView from "./CalendarView.js"
import UpcomingSchedule from "./UpcomingSchedule.js"
import ActivityFeed from "./ActivityFeed.js"
import "./DashboardMainContent.css"

const DashboardMainContent = () => {
  return (
    <main className="dashboard-main">
      <div className="dashboard-header">
        <h1 className="dashboard-title">Dashboard</h1>
        <div className="dashboard-controls">
          <select className="time-filter">
            <option>This Week</option>
            <option>This Month</option>
            <option>This Year</option>
          </select>
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="anatomy-column">
          <AnatomySection />
        </div>

        <div className="health-status-column">
          <HealthStatusCards />
        </div>

        <div className="calendar-column">
          <CalendarView />
        </div>

        <div className="schedule-column">
          <UpcomingSchedule />
        </div>

        <div className="activity-column">
          <ActivityFeed />
        </div>
      </div>
    </main>
  )
}

export default DashboardMainContent
