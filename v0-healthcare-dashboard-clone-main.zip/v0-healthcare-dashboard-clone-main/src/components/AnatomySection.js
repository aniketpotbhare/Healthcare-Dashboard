import { anatomyIndicators } from "../data/healthData.js"
import "./AnatomySection.css"

const AnatomySection = () => {
  return (
    <div className="anatomy-section">
      <div className="anatomy-container">
        <div className="anatomy-figure">
          <img src="/placeholder.svg?height=400&width=200" alt="Human Anatomy" className="anatomy-image" />
          {anatomyIndicators.map((indicator) => (
            <div
              key={indicator.id}
              className="anatomy-indicator"
              style={{
                top: indicator.position.top,
                left: indicator.position.left,
                backgroundColor: indicator.color,
              }}
            >
              {indicator.name}
            </div>
          ))}
        </div>
        <div className="anatomy-controls">
          <button className="zoom-control">🔍</button>
          <div className="slider-container">
            <input type="range" className="zoom-slider" />
          </div>
        </div>
      </div>
    </div>
  )
}

export default AnatomySection
