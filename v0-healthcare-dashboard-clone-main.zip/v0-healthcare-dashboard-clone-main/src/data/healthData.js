export const healthStatusData = [
  {
    id: 1,
    name: "Lungs",
    icon: "🫁",
    date: "Born: 26 Oct, 2021",
    progress: 85,
    color: "#ef4444",
  },
  {
    id: 2,
    name: "Teeth",
    icon: "🦷",
    date: "Born: 26 Oct, 2021",
    progress: 70,
    color: "#10b981",
  },
  {
    id: 3,
    name: "Bone",
    icon: "🦴",
    date: "Born: 26 Oct, 2021",
    progress: 60,
    color: "#ef4444",
  },
]

export const anatomyIndicators = [
  { id: 1, name: "Healthy Heart", position: { top: "35%", left: "45%" }, color: "#3b82f6" },
  { id: 2, name: "Healthy Leg", position: { top: "85%", left: "50%" }, color: "#06b6d4" },
]
