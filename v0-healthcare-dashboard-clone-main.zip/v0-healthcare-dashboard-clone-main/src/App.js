import Header from "./components/Header.js"
import Sidebar from "./components/Sidebar.js"
import DashboardMainContent from "./components/DashboardMainContent.js"
import "./App.css"

function App() {
  return (
    <div className="app">
      <Header />
      <div className="app-body">
        <Sidebar />
        <DashboardMainContent />
      </div>
    </div>
  )
}

export default App
